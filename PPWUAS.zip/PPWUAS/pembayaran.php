<!DOCTYPE html>
<html>
<head>
    <title>Pembayaran</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>PEMBAYARAN_ID</th>
            <th>TANGGAL_PEMBAYARAN</th>
            <th>JUMLAH_PEMBAYARAN</th>
            <th>STATUS_PEMBAYARAN</th>
            <th>SESI_ID</th>
          
           
        </tr>
        <?php 
            include 'conn.php'; // Include file koneksi
            $sql = "SELECT * FROM ppwuas.pembayaran;"; // Query untuk mengambil data
            $result = mysqli_query($conn, $sql); // Jalankan query

            if ($result) {
                $no = 1; // Deklarasi variabel $no di luar loop
                while ($d = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?= $no; ?></td>
            <td><?= $d["Pembayaran_id"]; ?></td>
            <td><?= $d["Tanggal_Pembayaran"]; ?></td>
            <td><?= $d["Jumlah_Pembayaran"]; ?></td>
            <td><?= $d["Metode_Pembayaran"]; ?></td>
            <td><?= $d["Status_Pembayaran"]; ?></td>
            <td><?= $d["Sesi_id"]; ?></td>
        </tr>
        <?php 
                    $no++; // Increment variabel $no
                }
            } else {
                echo "<tr><td colspan='6'>No data found</td></tr>";
            }

            mysqli_close($conn); // Tutup koneksi
        ?>
    </table>
</body>
</html>