function showSection(section) {
    document.querySelectorAll('.section').forEach(el => el.style.display = 'none');
    document.getElementById(section).style.display = 'block';
}

function showSessionDetails(sessionType, duration) {
    document.getElementById('session-details').textContent = sessionType;
    document.getElementById('duration').textContent = duration;
    document.getElementById('modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function startSession() {
    closeModal();
    alert('Sesi konseling dimulai!');
}

function validateForm() {
    let valid = true;

    // Nama
    const nama = document.getElementById('nama').value;
    if (nama.trim() === "") {
        valid = false;
        document.getElementById('nameFeedback').textContent = "Nama tidak boleh kosong";
    } else {
        document.getElementById('nameFeedback').textContent = "";
    }

    // Jenis Kelamin
    const jenis_kelamin = document.getElementById('jenis_kelamin').value;
    if (jenis_kelamin.trim() === "") {
        valid = false;
        document.getElementById('genderFeedback').textContent = "Jenis Kelamin tidak boleh kosong";
    } else {
        document.getElementById('genderFeedback').textContent = "";
    }

    // Usia
    const usia = document.getElementById('usia').value;
    if (usia.trim() === "" || isNaN(usia) || usia < 1) {
        valid = false;
        document.getElementById('ageFeedback').textContent = "Usia harus angka yang valid";
    } else {
        document.getElementById('ageFeedback').textContent = "";
    }

    // Jadwal
    const jadwal = document.getElementById('jadwal').value;
    if (jadwal.trim() === "") {
        valid = false;
        document.getElementById('scheduleFeedback').textContent = "Jadwal tidak boleh kosong";
    } else {
        document.getElementById('scheduleFeedback').textContent = "";
    }

    // Nomor WA
    const wa = document.getElementById('wa').value;
    if (wa.trim() === "" || isNaN(wa)) {
        valid = false;
        document.getElementById('waFeedback').textContent = "Nomor WA harus angka yang valid";
    } else {
        document.getElementById('waFeedback').textContent = "";
    }

    if (valid) {
        alert('Formulir berhasil disubmit!');
    }
}

function validateLogin() {
    let valid = true;

    // Username
    const username = document.getElementById('username').value;
    if (username.trim() === "") {
        valid = false;
        document.getElementById('usernameFeedback').textContent = "Username tidak boleh kosong";
    } else {
        document.getElementById('usernameFeedback').textContent = "";
    }

    // Password
    const password = document.getElementById('password').value;
    if (password.trim() === "") {
        valid = false;
        document.getElementById('passwordFeedback').textContent = "Password tidak boleh kosong";
    } else {
        document.getElementById('passwordFeedback').textContent = "";
    }

    if (valid) {
        alert('Login berhasil!');
    }
}
