<?php 
$servername = "127.0.0.1";
$username = "root";
$password = "";
$database = "PPWUAS";

$conn = mysqli_connect($servername, $username, $password, $database);
?>