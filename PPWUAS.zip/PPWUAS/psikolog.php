<!DOCTYPE html>
<html>
<head>
    <title>Psikolog</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>PSIKOLOG_ID</th>
            <th>NAMA_PSIKOLOG</th>
            <th>EMAIL</th>
            <th>NOMOR_TELEPON</th>
            <th>SPESIALISASI</th>
            <th>PENGALAMAN</th>
            <th>BIOGRAFI</th>
            <th>USERS_ID</th>
            <th>FOTO_PSIKOLOG</th>
        </tr>
        <?php 
            include 'conn.php'; // Include file koneksi
            $sql = "SELECT * FROM ppwuas.`list psikolog`;"; // Query untuk mengambil data
            $result = mysqli_query($conn, $sql); // Jalankan query

            if ($result) {
                $no = 1; // Deklarasi variabel $no di luar loop
                while ($d = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?= $no; ?></td>
            <td><?= $d["Psikolog_id"]; ?></td>
            <td><?= $d["Nama_Psikolog"]; ?></td>
            <td><?= $d["Email"]; ?></td>
            <td><?= $d["Nomor_Telepon"]; ?></td>
            <td><?= $d["Spesialisasi"]; ?></td>
            <td><?= $d["Pengalaman"]; ?></td>
            <td><?= $d["Biografi"]; ?></td>
            <td><?= $d["Users_id"]; ?></td>
            <td><?= $d["psikolog_img"]; ?></td>
        </tr>
        <?php 
                    $no++; // Increment variabel $no
                }
            } else {
                echo "<tr><td colspan='5'>No data found</td></tr>";
            }

            mysqli_close($conn); // Tutup koneksi
        ?>
    </table>
</body>
</html>