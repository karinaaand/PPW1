<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layanan Psikolog</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <!-- Navbar Section -->
    <div class="navbar">
        <a href="index.php" onclick="showSection('beranda')">Beranda</a>
        <a href="layananpsikologi.php" onclick="showSection('layanan')">Layanan Konseling</a>
        <a href="listpsikolog.php" onclick="showSection('list')">List Psikolog</a>
        <a href="tentangkami.php" onclick="showSection('tentang')">Tentang Kami</a>
        <a href="bookingsesi.php" onclick="showSection('booking')" class="booking">BOOKING SESI</a>
        <a href="#" onclick="showSection('auth')" class="masuk">MASUK</a>
    </div>
    <div id="layanan" class="container section">
        <div class="services">
            <h2>Layanan Konseling</h2>
            <div class="cards">
                <div class="card">
                    <img src="assets/image/Anak dan Remaja.jpg" alt="Anak dan Remaja">
                    <h3>Anak dan Remaja</h3>
                    <button onclick="showSessionDetails('Anak dan Remaja', '60 menit')">Mulai Konseling</button>
                </div>
                <div class="card">
                    <img src="assets/image/Keluarga.jpg" alt="Keluarga">
                    <h3>Keluarga</h3>
                    <button onclick="showSessionDetails('Keluarga', '60 menit')">Mulai Konseling</button>
                </div>
                <div class="card">
                    <img src="assets/image/Klinis.jpg" alt="Klinis">
                    <h3>Klinis</h3>
                    <button onclick="showSessionDetails('Klinis', '60 menit')">Mulai Konseling</button>
                </div>
                <div class="card">
                    <img src="assets/image/Manajemen stress.jpg" alt="Manajemen Stress">
                    <h3>Manajemen Stress</h3>
                    <button onclick="showSessionDetails('Manajemen Stress', '60 menit')">Mulai Konseling</button>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="footer-left">
            <h3>Mindmate</h3>
            <p>Mindmate adalah platform pengembangan diri untuk meningkatkan kesadaran diri, pengetahuan diri, kesejahteraan, dan kebahagiaan hidup.</p>
        </div>
        <div class="footer-right">
            <div class="follow-us">
                <p>Follow kami di</p>
                <div class="social-icons">
                    <a href="#"><img src="assets/image/instagram.png" alt="Instagram"></a>
                    <a href="#"><img src="assets/image/facebook.png" alt="Facebook"></a>
                    <a href="#"><img src="assets/image/youtube.png" alt="YouTube"></a>
                    <a href="#"><img src="assets/image/linkedin.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Section -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <div id="session-details"></div>
            <div id="duration"></div>
            <button onclick="startSession()">Mulai Konseling</button>
        </div>
    </div>

    <script src="assets/js/scripts.js"></script>
</body>
</html>
