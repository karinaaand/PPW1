
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Sesi</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <!-- Navbar Section -->
    <div class="navbar">
        <a href="index.php" onclick="showSection('beranda')">Beranda</a>
        <a href="layananpsikologi.php" onclick="showSection('layanan')">Layanan Konseling</a>
        <a href="listpsikolog.php" onclick="showSection('list')">List Psikolog</a>
        <a href="tentangkami.php" onclick="showSection('tentang')">Tentang Kami</a>
        <a href="bookingsesi.php" onclick="showSection('booking')" class="booking">BOOKING SESI</a>
        <a href="#" onclick="showSection('auth')" class="masuk">MASUK</a>
    </div>
     <!-- Booking Sesi Section -->
     <div id="booking" class="container section">
        <div class="form-wrapper">
            <h1>Booking Sesi</h1>
            <form>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama">

                <label for="jenis_kelamin">Jenis Kelamin</label>
                <input type="text" id="jenis_kelamin" name="jenis_kelamin">

                <label for="usia">Usia</label>
                <input type="text" id="usia" name="usia">

                <label for="jadwal">Paket & Jadwal Konseling</label>
                <input type="text" id="jadwal" name="jadwal">

                <label for="wa">Nomor WA untuk Konseling</label>
                <input type="text" id="wa" name="wa">

                <button type="submit">
                    <img src="assets/image/whatssapp.png" alt="Whatsapp Icon"> Daftar Via Whatsapp
                </button>
            </form>
        </div>
    </div>
    <div class="footer">
        <div class="footer-left">
            <h3>Mindmate</h3>
            <p>Mindmate adalah platform pengembangan diri untuk meningkatkan kesadaran diri, pengetahuan diri, kesejahteraan, dan kebahagiaan hidup.</p>
        </div>
        <div class="footer-right">
            <div class="follow-us">
                <p>Follow kami di</p>
                <div class="social-icons">
                    <a href="#"><img src="assets/image/instagram.png" alt="Instagram"></a>
                    <a href="#"><img src="assets/image/facebook.png" alt="Facebook"></a>
                    <a href="#"><img src="assets/image/youtube.png" alt="YouTube"></a>
                    <a href="#"><img src="assets/image/linkedin.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/scripts.js"></script>
</body>
</html>