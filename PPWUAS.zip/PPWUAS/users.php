<!DOCTYPE html>
<html>
<head>
    <title>Users</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>USERS_ID</th>
            <th>NAMA_LENGKAP</th>
            <th>EMAIL</th>
            <th>PASSWORD</th>
            <th>NOMOR_TELEPON</th>
            <th>ALAMAT</th>
        </tr>
        <?php 
            include 'conn.php'; // Include file koneksi
            $sql = "SELECT * FROM Users"; // Query untuk mengambil data
            $result = mysqli_query($conn, $sql); // Jalankan query

            if ($result) {
                $no = 1; // Deklarasi variabel $no di luar loop
                while ($d = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?= $no; ?></td>
            <td><?= $d["Users_id"]; ?></td>
            <td><?= $d["Nama_Lengkap"]; ?></td>
            <td><?= $d["Email"]; ?></td>
            <td><?= $d["Password"]; ?></td>
            <td><?= $d["Nomor_Telepon"]; ?></td>
            <td><?= $d["Alamat"]; ?></td>
        </tr>
        <?php 
                    $no++; // Increment variabel $no
                }
            } else {
                echo "<tr><td colspan='6'>No data found</td></tr>";
            }

            mysqli_close($conn); // Tutup koneksi
        ?>
    </table>
</body>
</html>