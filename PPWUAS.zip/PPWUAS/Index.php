<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mindmate</title>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- referensi ke file css -->
</head>
<body>
    <!-- Navbar Section -->
    <div class="navbar">
        <a href="index.php" onclick="showSection('beranda')">Beranda</a>
        <a href="layananpsikologi.php" onclick="showSection('layanan')">Layanan Konseling</a>
        <a href="listpsikolog.php" onclick="showSection('list')">List Psikolog</a>
        <a href="tentangkami.php" onclick="showSection('tentang')">Tentang Kami</a>
        <a href="bookingsesi.php" onclick="showSection('booking')" class="booking">BOOKING SESI</a>
        <a href="#" onclick="showSection('auth')" class="masuk">MASUK</a>
    </div>

    <!-- Main Content Section (Beranda) -->
    <div id="beranda" class="container section">
        <div class="content">
            <div class="text">
                <h2>Teman Jiwa,<br>Solusi Hidupmu!</h2>
            </div>
            <div class="image">
                <img src="assets/image/Beranda.jpeg" alt="Counseling Session">
            </div>
        </div>
    </div>

    <!-- Layanan Konseling Section -->
    <div id="layanan" class="container section" style="display:none;">
        <div class="services">
            <h2>Layanan Konseling</h2>
            <div class="cards">
                <div class="card">
                    <img src="assets/image/Anak dan Remaja.jpg" alt="Anak dan Remaja">
                    <h3>Anak dan Remaja</h3>
                    <button onclick="showSessionDetails('Anak dan Remaja', '60 menit')">Mulai Konseling</button>
                </div>
                <div class="card">
                    <img src="assets/image/Keluarga.jpg" alt="Keluarga">
                    <h3>Keluarga</h3>
                    <button onclick="showSessionDetails('Keluarga', '60 menit')">Mulai Konseling</button>
                </div>
                <div class="card">
                    <img src="assets/image/Klinis.jpg" alt="Klinis">
                    <h3>Klinis</h3>
                    <button onclick="showSessionDetails('Klinis', '60 menit')">Mulai Konseling</button>
                </div>
                <div class="card">
                    <img src="assets/image/Manajemen stress.jpg" alt="Manajemen Stress">
                    <h3>Manajemen Stress</h3>
                    <button onclick="showSessionDetails('Manajemen Stress', '60 menit')">Mulai Konseling</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Session Details -->
    <div id="modal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Detail Konseling</h2>
            <p id="session-details"></p>
            <p>Durasi: <span id="duration"></span></p>
            <button id="start-session" onclick="startSession()">Mulai Konseling</button>
        </div>
    </div>

    <!-- List Psikolog Section
    <div id="list" class="container section" style="display:none;">
        <div class="list-psikolog">
            <h2>List Psikolog</h2>
            <div class="list-content">
                <div class="psikolog-text">
                    <p>Apapun masalahmu, Psikolog Mindmate siap membantumu!<br>Kamu dapat memilih psikolog sesuai dengan kebutuhanmu.</p>
                </div>
                <div class="psikolog-card">
                    <div class="psikolog-img">
                        <img src="assets/image/Nurhuzaifah Amini, M.Psi..jpg" alt="Psikolog Anak dan Remaja">
                    </div>
                    <div class="psikolog-info">
                        <h3>Nurhuzaifah Amini, M.Psi.</h3>
                        <p>Psikolog Anak dan Remaja</p>
                        <p>Pengalaman: 4 tahun</p>
                    </div>
                </div>
                <div class="psikolog-card">
                    <div class="psikolog-img">
                        <img src="assets/image/Zia Majiatul Arobiah, M.Psi..jpg" alt="Psikolog Keluarga">
                    </div>
                    <div class="psikolog-info">
                        <h3>Zia Majiatul Arobiah, M.Psi.</h3>
                        <p>Psikolog Keluarga</p>
                        <p>Pengalaman: 6 tahun</p>
                    </div>
                </div>
                <div class="psikolog-card">
                    <div class="psikolog-img">
                        <img src="assets/image/Roselli Kezia Ausie, M.Psi..jpg" alt="Psikolog Klinis">
                    </div>
                    <div class="psikolog-info">
                        <h3>Roselli Kezia Ausie, M.Psi.</h3>
                        <p>Psikolog Klinis</p>
                        <p>Pengalaman: 5 tahun</p>
                    </div>
                </div>
                <div class="psikolog-card">
                    <div class="psikolog-img">
                        <img src="assets/image/B Sri Susanti, S.Psi..jpg" alt="Psikolog Manajemen Stress">
                    </div>
                    <div class="psikolog-info">
                        <h3>B Sri Susanti, S.Psi.</h3>
                        <p>Psikolog Manajemen Stress</p>
                        <p>Pengalaman: 7 tahun</p>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

    <!-- Apa Kata Mereka Section -->
    <div id="tentang" class="container quotes section" style="display:none;">
        <div class="title">
            <h1>Apa Kata Mereka</h1>
            <p>Kisah #PejuangKesehatanMental yang sudah menggunakan layanan Mindmate.<br>Kamu juga bisa seperti mereka, karena ceritamu layak didengar</p>
        </div>
        <div class="quotes-container">
            <div class="quote-card">
                <h3>Amelia Tri Cahyanti</h3>
                <p>Pelayanan yang sangat baik, sangat membantu saya dalam mengatasi masalah saya.</p>
                <p class="date">Sabtu, 1 Juni 2024</p>
            </div>
            <div class="quote-card">
                <h3>Fairuz Zahirah Abhista</h3>
                <p>Sangat puas dengan layanan psikologis yang diberikan. Sangat direkomendasikan.</p>
                <p class="date">Minggu, 2 Juni 2024</p>
            </div>
            <div class="quote-card">
                <h3>Assyfa Nur Fathona</h3>
                <p>Pelayanan cukup baik, tapi masih ada beberapa hal yang perlu diperbaiki.</p>
                <p class="date">Senin, 3 Juni 2024</p>
            </div>
            <div class="quote-card">
                <h3>Ibanez Centivola Ahista</h3>
                <p>Kurang puas dengan layanan yang diberikan.</p>
                <p class="date">Selasa, 4 Juni 2024</p>
            </div>
        </div>
    </div>

    <!-- Booking Sesi Section -->
    <div id="booking" class="container form-container section" style="display:none;">
        <div class="form-wrapper">
            <h1>Booking Sesi</h1>
            <form>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama">

                <label for="jenis_kelamin">Jenis Kelamin</label>
                <input type="text" id="jenis_kelamin" name="jenis_kelamin">

                <label for="usia">Usia</label>
                <input type="text" id="usia" name="usia">

                <label for="jadwal">Paket & Jadwal Konseling</label>
                <input type="text" id="jadwal" name="jadwal">

                <label for="wa">Nomor WA untuk Konseling</label>
                <input type="text" id="wa" name="wa">

                <button type="submit">
                    <img src="assets/image/whatssapp.png" alt="Whatsapp Icon"> Daftar Via Whatsapp
                </button>
            </form>
        </div>
    </div>

    <!-- Form Login Section -->
    <div id="auth" class="container section" style="display:none;">
        <div class="form-wrapper">
            <h1>Sign In</h1>
            <form>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                
                <button type="submit">Login</button>
            </form>
            <p>Belum punya akun? <a href="#" onclick="showSection('signup')">Sign Up</a></p>
        </div>
    </div>

    <!-- Form Sign Up Section -->
    <div id="signup" class="container section" style="display:none;">
        <div class="form-wrapper">
            <h1>Sign Up</h1>
            <form>
                <label for="new-username">Username</label>
                <input type="text" id="new-username" name="new-username" required>
                
                <label for="new-password">Password</label>
                <input type="password" id="new-password" name="new-password" required>
                
                <label for="confirm-password">Confirm Password</label>
                <input type="password" id="confirm-password" name="confirm-password" required>
                
                <button type="submit">Sign Up</button>
            </form>
            <p>Sudah punya akun? <a href="#" onclick="showSection('auth')">Sign in</a></p>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <div class="footer-left">
            <h3>Mindmate</h3>
            <p>Mindmate adalah platform pengembangan diri untuk meningkatkan kesadaran diri, pengetahuan diri, kesejahteraan, dan kebahagiaan hidup.</p>
        </div>
        <div class="footer-right">
            <div class="follow-us">
                <p>Follow kami di</p>
                <div class="social-icons">
                    <a href="#"><img src="assets/image/instagram.png" alt="Instagram"></a>
                    <a href="#"><img src="assets/image/facebook.png" alt="Facebook"></a>
                    <a href="#"><img src="assets/image/youtube.png" alt="YouTube"></a>
                    <a href="#"><img src="assets/image/linkedin.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/scripts.js"></script>
</body>
</html>