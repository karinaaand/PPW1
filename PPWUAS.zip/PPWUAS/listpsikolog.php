<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Psikolog</title>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- referensi ke file css -->
</head>
<body>
    <!-- Navbar Section -->   <!-- navigasi situs degan tautan ke beranda, layanan konseling, list psikolog, tentang kami, booking sesi dan masuk -->  
    <div class="navbar">
        <a href="index.php" onclick="showSection('beranda')">Beranda</a>
        <a href="layananpsikologi.php" onclick="showSection('layanan')">Layanan Konseling</a>
        <a href="listpsikolog.php" onclick="showSection('list')">List Psikolog</a>
        <a href="tentangkami.php" onclick="showSection('tentang')">Tentang Kami</a>
        <a href="bookingsesi.php" onclick="showSection('booking')" class="booking">BOOKING SESI</a>
        <a href="#" onclick="showSection('auth')" class="masuk">MASUK</a>
    </div>

    <!-- Koneksi Databse dan Query sql dalam menampilkan 1 tabel yang mengambil database list psikolog serta menampilkan dalam 
     bentuk-bentuk kartu yang berisi gambar, nama, spealisasi, dan pengalaman psikolog-->  
    <?php 
    include 'conn.php';
    
    $sql = "SELECT psikolog_img, spesialisasi, nama_psikolog, pengalaman FROM `list psikolog`;";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div id='list' class='container section'>";
        echo "<div class='list-psikolog'>";
        echo "<h2>List Psikolog</h2>";
        echo "<div class='list-content'>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<div class='psikolog-card'>";
            echo "    <div class='psikolog-img'>";
            echo "        <img src='" . $row['psikolog_img'] . "' alt='" . $row['spesialisasi'] . "'>";
            echo "    </div>";
            echo "    <div class='psikolog-info'>";
            echo "        <h3>" . $row['nama_psikolog'] . "</h3>";
            echo "        <p>Psikolog " . $row['spesialisasi'] . "</p>";
            echo "        <p>Pengalaman: " . $row['pengalaman'] . " tahun</p>";
            echo "    </div>";
            echo "</div>";
        }
        
        echo "</div>"; // close list-content
        echo "</div>"; // close list-psikolog
        echo "</div>"; // close container section
    } else {
        echo "<p>Tidak ada data psikolog yang ditemukan.</p>";
    }

    // Menutup koneksi
    $conn->close();
    ?>  

    <div class="footer">
        <div class="footer-left">
            <h3>Mindmate</h3>
            <p>Mindmate adalah platform pengembangan diri untuk meningkatkan kesadaran diri, pengetahuan diri, kesejahteraan, dan kebahagiaan hidup.</p>
        </div>
        <div class="footer-right">
            <div class="follow-us">
                <p>Follow kami di</p>
                <div class="social-icons">
                    <a href="#"><img src="assets/image/instagram.png" alt="Instagram"></a>
                    <a href="#"><img src="assets/image/facebook.png" alt="Facebook"></a>
                    <a href="#"><img src="assets/image/youtube.png" alt="YouTube"></a>
                    <a href="#"><img src="assets/image/linkedin.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
