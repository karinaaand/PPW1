<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Psikolog</title>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- referensi ke file css -->
</head>
<body>
    <!-- Navbar Section --> <!-- navigasi situs degan tautan ke beranda, layanan konseling, list psikolog, tentang kami, booking sesi dan masuk -->  
    <div class="navbar">
        <a href="index.php" onclick="showSection('beranda')">Beranda</a>
        <a href="#" onclick="showSection('layanan')">Layanan Konseling</a>
        <a href="listpsikolog.php" onclick="showSection('list')">List Psikolog</a>
        <a href="tentangkami.php" onclick="showSection('tentang')">Tentang Kami</a>
        <a href="bookingsesi.php" onclick="showSection('booking')" class="booking">BOOKING SESI</a>
        <a href="#" onclick="showSection('auth')" class="masuk">MASUK</a>
    </div>
    <div id="tentang" class="container quotes section">
        <div class="title">
            <h1>Apa Kata Mereka</h1>
            <p>Kisah #PejuangKesehatanMental yang sudah menggunakan layanan Mindmate.<br>Kamu juga bisa seperti mereka, karena ceritamu layak didengar</p>
        </div>
        <!-- merupakan kode yang telah terhubung ke database dengan melakukan query guna mengambil informasi dri tabel ulasan, users dan
         list psikolog menggunakan operasi JOIN untuk menghubungkan data dari ketiga tabel tersebut.
         Data ubu ditampilkan dalam bentuk kartu yang berisi nama pengguna, teks ulasan, dan tanggal ulasan yang telah dibuat
         pada sql workbench -->  
        <div class="quotes-container">
            <?php 
            include 'conn.php';
            
            $sql = "SELECT 
                        ulasan.Ulasan_id, 
                        ulasan.Penilaian, 
                        ulasan.Teks_Ulasan, 
                        ulasan.Tanggal_Ulasan, 
                        users.Nama_Lengkap AS nama_user, 
                        `list psikolog`.Nama_Psikolog AS nama_psikolog
                    FROM 
                       ulasan
                    JOIN 
                        users ON ulasan.Users_id = users.Users_id
                    JOIN 
                        `list psikolog` ON ulasan.Psikolog_id = `list psikolog`.Psikolog_id;
                ";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $tanggalUlasan = date("l, j F Y", strtotime($row['Tanggal_Ulasan']));
                    echo "<div class='quote-card'>";
                    echo "    <h3>" . $row['nama_user'] . "</h3>";
                    echo "    <p>" . $row['Teks_Ulasan'] . "</p>";
                    echo "    <p class='date'>" . $tanggalUlasan . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>Tidak ada ulasan yang ditemukan.</p>";
            }

            // Menutup koneksi
            $conn->close();
            ?>
        </div>
    </div>
    <div class="footer">
        <div class="footer-left">
            <h3>Mindmate</h3>
            <p>Mindmate adalah platform pengembangan diri untuk meningkatkan kesadaran diri, pengetahuan diri, kesejahteraan, dan kebahagiaan hidup.</p>
        </div>
        <div class="footer-right">
            <div class="follow-us">
                <p>Follow kami di</p>
                <div class="social-icons">
                    <a href="#"><img src="assets/image/instagram.png" alt="Instagram"></a>
                    <a href="#"><img src="assets/image/facebook.png" alt="Facebook"></a>
                    <a href="#"><img src="assets/image/youtube.png" alt="YouTube"></a>
                    <a href="#"><img src="assets/image/linkedin.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
